/* 
 *  pslash - a lightweight framebuffer splashscreen for embedded devices. 
 *
 *  Copyright (c) 2006 Matthew Allum <mallum@o-hand.com>
 *
 *  Parts of this file ( fifo handling ) based on 'usplash' copyright 
 *  Matthew Garret.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 */

#include "psplash.h"
#include "psplash-poky-img.h"
#include "psplash-bar-img.h"
#include "radeon-font.h"

#define MSG ""

#define PROG_BAR_X   244
#define PROG_BAR_Y   361

void
psplash_exit (int signum)
{
  DBG("mark");

  psplash_console_reset ();
}

void
psplash_draw_msg (PSplashFB *fb, const char *msg)
{
  int w, h;

  psplash_fb_text_size (fb, &w, &h, &radeon_font, msg);

  DBG("displaying '%s' %ix%i\n", msg, w, h);

  /* Clear */

  psplash_fb_draw_rect (fb, 
			0, 
			fb->height - (fb->height/6) - h, 
			fb->width,
			h,
			PSPLASH_BACKGROUND_COLOR);

  psplash_fb_draw_text (fb,
			(fb->width-w)/2, 
			fb->height - (fb->height/6) - h,
			PSPLASH_TEXT_COLOR,
			&radeon_font,
			msg);
}

void
psplash_draw_progress (PSplashFB *fb, int value)
{
  int x, y, width, height, barwidth;

  /* 4 pix border */
  x      = PROG_BAR_X + 2;
  y      = PROG_BAR_Y + 2;
  width  = BAR_IMG_WIDTH - 4; 
  height = BAR_IMG_HEIGHT - 4;

  if (value > 0)
    {
      barwidth = (CLAMP(value,0,100) * width) / 100;
      psplash_fb_draw_rect (fb, x + barwidth, y, 
    			width - barwidth, height,
			PSPLASH_BAR_BACKGROUND_COLOR);
      psplash_fb_draw_rect (fb, x, y, barwidth,
			    height, PSPLASH_BAR_COLOR);
    }
  else
    {
      barwidth = (CLAMP(-value,0,100) * width) / 100;
      psplash_fb_draw_rect (fb, x, y, 
    			width - barwidth, height,
			PSPLASH_BAR_BACKGROUND_COLOR);
      psplash_fb_draw_rect (fb, x + width - barwidth,
			    y, barwidth, height,
			    PSPLASH_BAR_COLOR);
    }

  DBG("value: %i, width: %i, barwidth :%i\n", value, 
		width, barwidth);
}

static int parse_command (PSplashFB *fb, char *string, int length)
{
  char *command;
  int   parsed=0;

  parsed = strlen(string)+1;

  printf("got cmd====== %s", string);
	
  if (strcmp(string,"QUIT") == 0)
    return 1;

  command = strtok(string," ");

  if (!strcmp(command,"PROGRESS")) 
    {
//      psplash_draw_progress (fb, atoi(strtok(NULL,"\0")));
    } 
  else if (!strcmp(command,"MSG")) 
    {
      psplash_draw_msg (fb, strtok(NULL,"\0"));
    } 
  else if (!strcmp(command,"QUIT")) 
    {
      return 1;
    }

  return 0;
}//*/

#define DOT_COLOR_BACKGROUND PSPLASH_BACKGROUND_COLOR
//#define DOT_COLOR 0X78 ,0x7c ,0x78/*灰*/
#define DOT_COLOR 0 ,0 ,0
#define DOT_X 410/*high_power*/
//#define DOT_X 422
#define DOT_Y 508/*high_power*/
//#define DOT_Y 497
#define DOT_WIDTH 10
#define DOT_NUMS 7
#define DOT_SIZE 3
#if 0
void psplash_clear_rect(PSplashFB *fb,
	       int          x,
	       int          y,
		   int          width,
		   int          height,
	       int          img_width,
	       int          img_height,
	       int          img_bytes_per_pixel,
	       uint8       *rle_data)
{
	int dx, dy;
	int index ;
	uint8       *p = rle_data;
	int          total_len;
	unsigned int len;
	int 		  indexLen = 0;

	total_len = img_width * img_height * img_bytes_per_pixel;
	  for (dy=0; dy < height; dy++)
	  {
		  for (dx=0; dx < width; dx++)
		  {

			index = img_width * (y + dy - ((fb->height * 5) / 6 - POKY_IMG_HEIGHT)/2) +(x + dx - (fb->width  - POKY_IMG_WIDTH)/2);
			/* FIXME: Optimise, check for over runs ... */
			while ((p - rle_data) < total_len)
			{
				len = *(p++);
				if (len & 128)
				{
				  len -= 128;
				}
				indexLen += len;
				if(indexLen > index)
				{
				    if (img_bytes_per_pixel < 4 || *(p+3))
				    	psplash_fb_plot_pixel (fb, x+dx, y+dy, *(p), *(p+1), *(p+2));
					break;
				}
				p += img_bytes_per_pixel;
			}
		  }
	  }
}
#endif

void psplash_dot_progress(PSplashFB *fb ,int prog)
{
	int x ,y ,widthPerDot ,xDot;

	x = DOT_X;
	y = DOT_Y;
	widthPerDot = DOT_WIDTH;
	if(0 == prog)
	{
	  /* Draw the Poky logo  */
	  psplash_fb_draw_image (fb,
				 (fb->width  - POKY_IMG_WIDTH)/2,
				 (fb->height - POKY_IMG_HEIGHT)/2,
				 POKY_IMG_WIDTH,
				 POKY_IMG_HEIGHT,
				 POKY_IMG_BYTES_PER_PIXEL,
				 POKY_IMG_RLE_PIXEL_DATA);//*/
	}
	else
	{
		xDot = x + prog * widthPerDot;
		psplash_fb_draw_rect(fb ,xDot ,y ,DOT_SIZE ,DOT_SIZE ,DOT_COLOR);
	}
}
#define LZK 1
#if LZK
PSplashFB* gFb;
void TimeOut(int sig_num)
{
	static int count = 0;
	psplash_dot_progress(gFb ,count++);
	if(DOT_NUMS == count)
		count = 0;

}
#endif
void
psplash_main (PSplashFB *fb, int pipe_fd, int timeout)
{
#ifndef LZK
  int prog = 0;
  int breakTime = 0;
#else
  int            err;
  ssize_t        length = 0;
#endif
  fd_set         descriptors;
  struct timeval tv;
  char          *end;
  char           command[2048];

  tv.tv_sec = timeout;
  tv.tv_usec = 0;

  FD_ZERO(&descriptors);
  FD_SET(pipe_fd, &descriptors);

  end = command;

  while (1)
    {
#ifndef LZK
		psplash_dot_progress(fb ,prog++);
		if(DOT_NUMS == prog)
			prog = 0;
		usleep(300000);//300ms
		if(20 <= breakTime ++)//6s
			break;
#else
      if (timeout != 0)
    	  err = select(pipe_fd+1, &descriptors, NULL, NULL, &tv);
      else
    	  err = select(pipe_fd+1, &descriptors, NULL, NULL, NULL);

      if (err <= 0)
      {
		  /*
		  if (errno == EINTR)
			continue;
		  */
			//  printf("err:%d\n" ,err);
			  continue;
			 // return;
      }

      length += read (pipe_fd, end, sizeof(command) - (end - command));

      if (length == 0)
		{
		  /* Reopen to see if there's anything more for us */
		  close(pipe_fd);
		  pipe_fd = open(PSPLASH_FIFO,O_RDONLY|O_NONBLOCK);
		  goto out;
		}

      if (command[length-1] == '\0')
		{
		  if (parse_command(fb, command, strlen(command)))
			return;
		  length = 0;
		}
      else if (command[length-1] == '\n')
		{
		  command[length-1] = '\0';
		  if (parse_command(fb, command, strlen(command)))
			return;
		  length = 0;
		}


		out:
		  end = &command[length];

		  tv.tv_sec = timeout;
		  tv.tv_usec = 0;

		  FD_ZERO(&descriptors);
		  FD_SET(pipe_fd,&descriptors);
#endif
    }

  return;
}


int 
main (int argc, char** argv) 
{
	  char      *tmpdir;
	  int        pipe_fd, i = 0, angle = 0, ret = 0;
	  PSplashFB *fb;
	  bool       disable_console_switch = FALSE;

	  signal(SIGHUP, psplash_exit);
	  signal(SIGINT, psplash_exit);
	  signal(SIGQUIT, psplash_exit);

	  while (++i < argc)
	    {
	      if (!strcmp(argv[i],"-n") || !strcmp(argv[i],"--no-console-switch"))
	        {
		  disable_console_switch = TRUE;
		  continue;
		}

	      if (!strcmp(argv[i],"-a") || !strcmp(argv[i],"--angle"))
	        {
		  if (++i >= argc) goto fail;
		  angle = atoi(argv[i]);
		  continue;
		}

	    fail:
	      fprintf(stderr,
		      "Usage: %s [-n|--no-console-switch][-a|--angle <0|90|180|270>]\n",
		      argv[0]);
	      exit(-1);
	    }

	  tmpdir = getenv("TMPDIR");

	  if (!tmpdir)
	    tmpdir = "/tmp";

	  (void)chdir(tmpdir);

	  if (mkfifo(PSPLASH_FIFO, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP))
	    {
	      if (errno!=EEXIST)
		{
		  perror("mkfifo");
		  exit(-1);
		}
	    }

	  pipe_fd = open (PSPLASH_FIFO,O_RDONLY|O_NONBLOCK);

	  if (pipe_fd==-1)
	    {
	      perror("pipe open");
	      exit(-2);
	    }

	  if (!disable_console_switch)
	    psplash_console_switch ();

	  if ((fb = psplash_fb_new(angle)) == NULL) {
		  ret = -1;
		  goto fb_fail;
	  }

  /* Clear the background with #ecece1 */
  psplash_fb_draw_rect (fb, 0, 0, fb->width, fb->height,
                        PSPLASH_BACKGROUND_COLOR);

  /* Draw the Poky logo  */
/*  psplash_fb_draw_image (fb,
			 (fb->width  - POKY_IMG_WIDTH)/2,
			 (fb->height - POKY_IMG_HEIGHT)/2,
			 POKY_IMG_WIDTH,
			 POKY_IMG_HEIGHT,
			 POKY_IMG_BYTES_PER_PIXEL,
			 POKY_IMG_RLE_PIXEL_DATA);//*/

  /*Draw progress bar border*/
  /*psplash_fb_draw_image (fb,
			 (fb->width  - BAR_IMG_WIDTH)/2,
			 fb->height - (fb->height/6),
			 BAR_IMG_WIDTH,
			 BAR_IMG_HEIGHT,
			 BAR_IMG_BYTES_PER_PIXEL,
			 BAR_IMG_RLE_PIXEL_DATA);*/
//  psplash_fb_draw_image(fb,PROG_BAR_X, PROG_BAR_Y,  BAR_IMG_WIDTH, BAR_IMG_HEIGHT,
//		  BAR_IMG_BYTES_PER_PIXEL, BAR_IMG_RLE_PIXEL_DATA);
//  psplash_draw_progress (fb, 0);

//  psplash_draw_msg (fb, MSG);
#if LZK
  gFb = fb;
  signal(SIGALRM ,TimeOut);
  struct itimerval value;
  value.it_value.tv_sec = 0;
  value.it_value.tv_usec = 300000;
  value.it_interval.tv_sec = 0;
  value.it_interval.tv_usec = 300000;
  setitimer(ITIMER_REAL, &value, NULL);
  TimeOut(0);
#endif
  psplash_main (fb, pipe_fd, 0);

  psplash_fb_destroy (fb);

 fb_fail:
  unlink(PSPLASH_FIFO);

  if (!disable_console_switch)
    psplash_console_reset ();

  return ret;
}
